package com.bc181.yuliatin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.bc181.pahlevi.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DatabaseHandler extends SQLiteOpenHelper {

    private final static int DATABASE_VERSION = 1;
    private final static String DATABASE_NAME = "db_beritaku";
    private final static String TABLE_BERITA = "t_berita";
    private final static String KEY_ID_BERITA = "ID_Berita";
    private final static String KEY_JUDUL = "Judul";
    private final static String KEY_TGL = "Tanggal";
    private final static String KEY_GAMBAR = "Gambar";
    private final static String KEY_CAPTION = "Caption";
    private final static String KEY_PENULIS = "Penulis";
    private final static String KEY_ISI_BERITA ="Isi_Berita";
    private final static String KEY_LINK = "Link";
    private SimpleDateFormat sdFormat = new SimpleDateFormat("dd/mm/yyyy hh:mm", Locale.getDefault());
    private Context context;

    public DatabaseHandler(Context ctx) {
        super(ctx,DATABASE_NAME,null,DATABASE_VERSION);
        this.context = ctx;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_BERITA = "CREATE TABLE " + TABLE_BERITA
                + "(" + KEY_ID_BERITA + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_JUDUL +  " TEXT, " + KEY_TGL + " DATE, "
                + KEY_GAMBAR + " TEXT, " + KEY_CAPTION + " TEXT, "
                + KEY_PENULIS + " TEXT, " + KEY_ISI_BERITA + " TEXT, "
                + KEY_LINK + " TEXT);";

        db.execSQL(CREATE_TABLE_BERITA);
        inisialisasiBeritaAwal(db);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_BERITA;
        db.execSQL(DROP_TABLE);
        onCreate(db);

    }

    public void tambahBerita(Berita dataBerita){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBerita.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBerita.getTanggal()));
        cv.put(KEY_GAMBAR,dataBerita.getGambar());
        cv.put(KEY_CAPTION,dataBerita.getCaption());
        cv.put(KEY_PENULIS,dataBerita.getPenulis());
        cv.put(KEY_ISI_BERITA,dataBerita.getIsiBerita());
        cv.put(KEY_LINK,dataBerita.getLink());

        db.insert(TABLE_BERITA, null,cv);

    }

    public void tambahBerita(Berita dataBerita,SQLiteDatabase db){
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBerita.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBerita.getTanggal()));
        cv.put(KEY_GAMBAR,dataBerita.getGambar());
        cv.put(KEY_CAPTION,dataBerita.getCaption());
        cv.put(KEY_PENULIS,dataBerita.getPenulis());
        cv.put(KEY_ISI_BERITA,dataBerita.getIsiBerita());
        cv.put(KEY_LINK,dataBerita.getLink());

        db.insert(TABLE_BERITA, null,cv);

    }
    public void editBerita(Berita dataBerita){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBerita.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBerita.getTanggal()));
        cv.put(KEY_GAMBAR,dataBerita.getGambar());
        cv.put(KEY_CAPTION,dataBerita.getCaption());
        cv.put(KEY_PENULIS,dataBerita.getPenulis());
        cv.put(KEY_ISI_BERITA,dataBerita.getIsiBerita());
        cv.put(KEY_LINK,dataBerita.getLink());

        db.update(TABLE_BERITA, cv, KEY_ID_BERITA + "=?" , new String[]{String.valueOf(dataBerita.getIdBerita())});
        db.close();

    }

    public void hapusBerita(int idBerita){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_BERITA, KEY_ID_BERITA + "=?", new String[]{String.valueOf(idBerita)});
        db.close();
    }

    public ArrayList<Berita> getAllBerita(){
        ArrayList<Berita> dataBerita = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_BERITA;
        SQLiteDatabase db = getReadableDatabase();
        Cursor csr = db.rawQuery(query, null);
        if (csr.moveToFirst()){
            do{
                Date tempDate = new Date();
                try{
                    tempDate = sdFormat.parse(csr.getString(2));
                }catch (ParseException er){
                    er.printStackTrace();
                }

                Berita tempBerita = new Berita(
                        csr.getInt(0),
                        csr.getString(1),
                        tempDate,
                        csr.getString(3),
                        csr.getString(4),
                        csr.getString(5),
                        csr.getString(6),
                        csr.getString(7)
                );

                dataBerita.add(tempBerita);
            }while (csr.moveToNext());
        }
        return dataBerita;
    }

    private String storeImageFile(int id){
        String location;
        Bitmap image = BitmapFactory.decodeResource(context.getResources(),id);
        location = InputActivity.saveImageToInternalStorage(image, context);
        return location;
    }

    private void  inisialisasiBeritaAwal(SQLiteDatabase db) {
        int idBerita = 0;
        Date tempDate = new Date();

        //Menambah data berita ke -1
        try{
            tempDate = sdFormat.parse( "20/01/2020 12:00");
        }catch(ParseException er){
            er.printStackTrace();
        }
        Berita berita1 = new Berita(
                idBerita,
                "Harry Potter and the Philosopher's Stone",
                tempDate,
                storeImageFile(R.drawable.film1),
                "Ilustrasi Poster Film",
                "J. K. Rowling",
                "Harry Potter, seorang anak yatim berusia sebelas tahun, menemukan bahwa dia adalah seorang penyihir dan diundang untuk belajar di Hogwarts. Bahkan ketika dia lolos dari kehidupan suram dan memasuki dunia sihir, dia menemukan kesulitan menunggunya.",
                "https://terbit21.cool/harry-potter-sorcerers-stone-2001/"

        );

        tambahBerita(berita1, db);
        idBerita++;

        // Membentuk obyek data berita 2
        tempDate = new Date();
        try{
            tempDate = sdFormat.parse( "01/01/2014 12:00");
        }catch(ParseException er){
            er.printStackTrace();
        }
        Berita berita2 = new Berita(
                idBerita,
                "Ilustrasi Poster Film",
                tempDate,
                storeImageFile(R.drawable.film2),
                "Ilustrasi Poster Film",
                "J. K. Rowling",
                "Peri rumah memperingatkan Harry agar tidak kembali ke Hogwarts, tetapi dia memutuskan untuk mengabaikannya. Ketika siswa dan makhluk di sekolah mulai membatu, Harry mendapati dirinya dikelilingi oleh misteri.",
                "https://terbit21.cool/harry-potter-chamber-secrets-2002/"

        );
        tambahBerita(berita2, db);
        idBerita++;

        // Membentuk obyek data berita 3
        tempDate = new Date();
        try{
            tempDate = sdFormat.parse( "12/03/2020 22:46");
        }catch(ParseException er){
            er.printStackTrace();
        }
        Berita berita3 = new Berita(
                idBerita,
                "Harry Potter and the Prisoner of Azkaban",
                tempDate,
                storeImageFile(R.drawable.film3),
                "Ilustrasi Poster Film",
                "J. K. Rowling",
                "Harry Potter mengetahui bahwa Sirius Black telah melarikan diri dari penjara Azkaban dan berencana untuk membunuhnya. Sementara itu, Hagrid bingung ketika hippogriff-nya, Buckbeak, dijatuhi hukuman mati.",
                "https://terbit21.cool/harry-potter-prisoner-azkaban-2004/"

        );
        tambahBerita(berita3, db);
        idBerita++;

        // Membentuk obyek data berita 4
        tempDate = new Date();
        try{
            tempDate = sdFormat.parse( "13/03/2020 05:58");
        }catch(ParseException er){
            er.printStackTrace();
        }
        Berita berita4 = new Berita(
                idBerita,
                "Harry Potter and the Goblet of Fire",
                tempDate,
                storeImageFile(R.drawable.film4),
                "Ilustrasi Poster Film",
                "J. K. Rowling",
                "Pada tahun keempatnya di Hogwarts, tanpa disadari Harry dipilih untuk bersaing di Turnamen Triwizard antar sekolah. Sementara itu, dunia sihir tetap tidak menyadari kebangkitan kekuatan gelap yang tidak menyenangkan.",
                "https://terbit21.cool/harry-potter-goblet-fire-2005/"
        );
        tambahBerita(berita4, db);
    }

}
